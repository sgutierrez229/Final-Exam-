#!/usr/bin/env bash
# print_1_to_50.sh
# Prints numbers 1 through 50, one per line. Supports optional --reverse.

if [[ $1 == "--reverse" ]]; then
  for ((n=50; n>=1; n--)); do
    echo "$n"
  done
  exit 0
fi

for ((n=1; n<=50; n++)); do
  echo "$n"
done
